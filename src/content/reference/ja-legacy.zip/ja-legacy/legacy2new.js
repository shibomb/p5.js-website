/**
 * /src/content/reference/ja-legacy/legacy2new.js
 * 
 * cd /src/content/reference/ja-legacy/
 * node legacy2new.js
 */
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import matter from "gray-matter";
import { compile } from "@mdx-js/mdx";

const CLASS_DATAS = ["description", "params", "returns"];

async function splitJsonElements(inputFile) {
  // console.log("inputFile:" + inputFile);

  // load json file
  const data = await fs.readFile(inputFile, "utf-8");
  // , async (err, data) => {
  //   if (err) {
  //     console.error("Failed to read file:", err);
  //     return;
  //   }

  const jsonData = JSON.parse(data);
  // console.log("jsonData:" + jsonData)

  for (const [key, value] of Object.entries(jsonData)) {
    // console.log("key1:" + key)

    for (const [key2, value2] of Object.entries(value)) {
      // console.log("key2:" + key2)

      await processMdxFile(key, key2, value2);
      // const outputFile = path.join(outputDir2, `${key2}.json`);
      // fs.writeFile(
      //   outputFile,
      //   JSON.stringify(value2, null, 4),
      //   'utf-8',
      //   err => {
      //     if (err) {
      //       console.error(`${key}.json : faild to write:`, err);
      //     } else {
      //       console.log(`${key}.json :created.`);
      //     } 
      //   }
      // );
    }
  }
  // });
}

async function processMdxFile(key1, key2, value2) {
  const filePath = await srcMdxFilePath(key1, key2);
  
  try {
    if (filePath == null) {
      return;
    }
    const outFilePath = outMdxFilePath(filePath);
    await fs.mkdir(path.dirname(outFilePath), { recursive: true });
    await fs.copyFile(filePath, outFilePath);

      const mdxContent = await readMdxFile(outFilePath);

      const editedContent = await editMdxContent(mdxContent, value2);

      // const compiledContent = await compile(editedContent);

      // await saveMdxFile(outFilePath, String(compiledContent));
      
      await saveMdxFile(outFilePath, String(editedContent));

  } catch (err) {
    console.error(`Erroered!:${filePath}`, err);
  }
}

async function srcMdxFilePath(key1, key2) {
  if (!Number.isNaN(parseInt(key2, 10))) {
    return null;
  }

  let filePath = null;
  if (!CLASS_DATAS.includes(key2)) {
    filePath = path.join("..", "en", key1, `${key2}.mdx`);
  } else {
    filePath = path.join("..", "en", "p5", `${key1}.mdx`);
    // console.log("class:" + filePath)
  }

  try {
    await fs.access(filePath, fs.constants.F_OK);

    const checkCase = await fileExistsWithCase(filePath);
    if (!checkCase) {
      throw new Error("fileExistsWithCase error");
    }
  } catch (err) {
    if (!CLASS_DATAS.includes(key2)) {
      filePath = path.join("..", "en", key1, "constants", `${key2}.mdx`);
    } else {
      filePath = path.join("..", "en", "p5.sound", `${key1}.mdx`);
      // console.log("sound class:" + filePath)
    }

    try {
      await fs.access(filePath, fs.constants.F_OK);
    } catch (err) {
      console.log(`${key1}/${key2}.mdx not found`);
      filePath = null;
    }
  }

  // console.log(`ok:${filePath}`)
  return filePath;
}

async function fileExistsWithCase(filePath) {
  const dir = path.dirname(filePath);
  const fileName = path.basename(filePath);

  const files = await fs.readdir(dir);
  return files.includes(fileName);
}

function outMdxFilePath(srcFilePath) {
  return srcFilePath.replace(`..${path.sep}en`, `..${path.sep}ja`);
}

async function readMdxFile(filePath) {
  const mdxContent = await fs.readFile(filePath, "utf8");
  return mdxContent;
}

function splitAtFirstPeriod(text) {
  const index = text.indexOf('。');
  if (index === -1) {
    // 句点が見つからない場合は、元の文字列を配列として返す
    return [text];
  }
  const beforePeriod = text.substring(0, index);
  const afterPeriod = text.substring(index + 1);
  return [beforePeriod, afterPeriod];
}

async function editMdxContent(mdxContent, value) {
  const parsedContent = matter(mdxContent);

  // parsedContent.data.title = 'Updated Title';

  // console.log(parsedContent.data);
  // console.log(value);
  // const valueStr = JSON.stringify(value, null, 4)

  if (value.description) {
//   parsedContent.data.description += `
// <div class="w-full mt-8 bg-gray-400 p-2">
//   <h6 class="text-white font-bold pb-2">WIP: こちらは旧バージョンの日本語リソースです</h6>
//   <pre class="w-full p-2 bg-white whitespace-break-spaces">
//   ${value.description}
//   </pre>
// </div>
// `
console.log(value.description)
    let tmp = ''
    for (let i = 0; i < value.description.length; i++) {
      const row = value.description[i]

      if (i == 0) {
        const [first, last] = splitAtFirstPeriod(row)
        tmp += `<p>${ first }。</p>\n`
        if (last != undefined) {
          tmp += `<p>${ last }</p>\n`
        }
      }
      else {
        tmp += `<p>${ row }</p>\n`
      }
    }
    parsedContent.data.description = `${tmp}
<hr/>
${parsedContent.data.description}`
  }

  // params
  if (parsedContent.data.itemtype == 'method') {
    if (parsedContent.data.params) {
      for(const [idx, param] of Object.entries(parsedContent.data.params)) {
        // console.log("value.params:", value.params);
        // console.log("param.name:", param.name);
        let tmp = ''
        try {
          tmp = value.params[param.name];
          tmp = tmp.replace(`${param.type}: `, '')
          // console.log("tmp:", tmp);
          param.description = `<p>${ tmp }</p>
${param.description}`
        }
        catch(err) {
          // console.error(param.name, [err, value])
          parsedContent.data.description = `${parsedContent.data.description}
<pre>
todo: param ${param.name} not found in ja-legacy:
${JSON.stringify(value.params, null, 4)}
</pre>`
        }
      }
    }

    if (parsedContent.data.overloads) {
      parsedContent.data.description = `${parsedContent.data.description}
<pre>
todo: update overloads.
${JSON.stringify(value.params, null, 4)}
</pre>`
    }

    if (parsedContent.data.return) {
        let tmp;        
        try {
          tmp = value.returns;
          // console.log("tmp:", tmp);
          tmp = tmp.replace(`${parsedContent.data.return.type}: `, '')
          parsedContent.data.return.description = `${ tmp }
${parsedContent.data.return.description}`
        }
        catch(err) {
          parsedContent.data.description = `${parsedContent.data.description}
<pre>
todo: return not found in ja-legacy.
</pre>`
        }
    }
  }


  const newContent = matter.stringify(
    parsedContent.content,
    parsedContent.data,
  );

  return newContent;
}

async function saveMdxFile(filePath, mdxContent) {
  await fs.writeFile(filePath, mdxContent, "utf8");
}

// run
const inputFile = "ja.json";
splitJsonElements(inputFile);
